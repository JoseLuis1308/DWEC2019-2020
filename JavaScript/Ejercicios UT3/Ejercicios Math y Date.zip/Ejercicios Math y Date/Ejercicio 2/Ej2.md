---
title: CCalcular cuantos dias faltan para navidad
author: Jose Luis Lafuente Pericacho
lang: es-ES
---

# Ejercicio 2
## Calcular cuantos dias faltan para navidad

Se crean dos variables, una con la fecha actual y otra con la fecha de navdad, utilizando el año de la fech actual. A continuacion se resta la fecha de navidad con la fecha actual y esto nos da el resultado en milisegundos, por lo que lo unico que hay que hacer es convertirlo a días.

```
Utilzar el metodo Math.round() para redondear el día, ya que lo mas probable es que el resultado en dias sea un número decimal
```