---
title: Reloj
author: Jose Luis Lafuente Pericacho
lang: es-ES
---

# Ejercicio 4
## Reloj

Para hacer un reloj en html, lo que se necesita es el método interval() del objeto object.
Utilizando esto, lo unico que necesitamos es crear una función que cargue el tiempo actual cada vez que sela llame.
De tal manera que se utilizará el método interval, con la funcion que llama al tiempo actual
y e le pondrá un tiempo de recarga de 1 segundo, para que se actualice cada segundo y podamos ver como cambia.
