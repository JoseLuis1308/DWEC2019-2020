---
title: Calcular el área de un triángulo
author: Jose Luis Lafuente Pericacho
lang: es-ES
---

# Ejercicio 7
## calcular el área de un triángulo

Lo unico que hay que hacer es obtener los valores de la base y la altura que pasan por pantalla
y realizar la operación y al resultado redondearlo con dos decmiales mediante el metodo toFixed() al que hay que pasarle el número de decimales que quieres.

```
numero.toFixed(2);
```